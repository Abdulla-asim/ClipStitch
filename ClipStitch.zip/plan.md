﻿# clipstitch — Detailed Implementation Plan

## Overview

clipstitch is a Windows desktop utility that silently monitors your clipboard history, stores every copied item locally, and uses an LLM to stitch your session's clips into a meaningful narrative. You can then export that narrative as a story, summary, work log, research digest, email draft, or a professionally formatted PDF report.

The app runs as a **background tray process** with a **local web UI** (Flask + HTML/JS) that you open on demand to review clips, generate outputs, and export.

---

## Tech Stack

| Layer | Technology | Reason |
|---|---|---|
| Language | Python 3.10+ | Broad library support, easy LLM SDKs |
| Clipboard access | `pywin32` (Win32 API) | Event-driven `WM_CLIPBOARDUPDATE` — instant, zero CPU waste |
| LLM SDKs | `openai`, `google-generativeai` | Direct SDKs — no LangChain needed (see note below) |
| Database | SQLite via `sqlite3` (stdlib) | Zero-config local storage |
| Web UI | Flask + Vanilla HTML/CSS/JS | Lightweight local server, no build step |

| Local LLM | `ollama` Python client | Run Llama / Mistral locally |
| PDF export | `reportlab` | Full control over PDF layout |
| Markdown export | stdlib `pathlib` | No extra dependency |
| System tray | `pystray` + `Pillow` | Windows tray icon |
| Hotkeys | `keyboard` | Global hotkey registration |
| Config | `python-dotenv` + JSON | API keys in `.env`, settings in `config.json` |
| Packaging | `pyinstaller` | Single `.exe` for distribution |

> **Why not LangChain?** LangChain adds heavy dependencies and frequent breaking changes for something our lean `provider.py` abstraction already covers cleanly. If agentic features are added later (e.g., auto-researching URLs), LangChain can be introduced at that point.

---

## Project Structure

```
clipstitch/
├── plan.md                    # This file
├── README.md
├── requirements.txt
├── .env.example               # Template for API keys
├── config.json                # User settings (model, session gap, etc.)
│
├── clipstitch/                 # Main Python package
│   ├── __init__.py
│   ├── main.py                # Entry point — starts tray + web server
│   │
│   ├── monitor/
│   │   ├── __init__.py
│   │   ├── clipboard.py       # Event-driven Win32 clipboard listener
│   │   └── session.py         # Session detection & deduplication
│   │
│   ├── db/
│   │   ├── __init__.py
│   │   ├── schema.sql         # SQLite schema
│   │   └── store.py           # CRUD operations
│   │
│   ├── llm/
│   │   ├── __init__.py
│   │   ├── provider.py        # LLM provider abstraction
│   │   ├── prompts.py         # Prompt templates for each output mode
│   │   └── generator.py       # Calls provider with clips + mode
│   │
│   ├── export/
│   │   ├── __init__.py
│   │   ├── pdf.py             # PDF report generation (reportlab)
│   │   └── markdown.py        # Markdown / plain-text export
│   │
│   ├── web/
│   │   ├── __init__.py
│   │   ├── app.py             # Flask application + API routes
│   │   └── templates/
│   │       └── index.html     # Single-page UI
│   │   └── static/
│   │       ├── style.css
│   │       └── app.js
│   │
│   └── tray/
│       ├── __init__.py
│       └── icon.py            # pystray setup, menu, hotkey binding
│
├── assets/
│   └── icon.png               # Tray icon
│
└── tests/
    ├── test_clipboard.py
    ├── test_session.py
    ├── test_store.py
    ├── test_generator.py
    └── test_export.py
```

---

## Phase 1 — Core Engine

### 1.1 Database Schema (`db/schema.sql`)

```sql
CREATE TABLE IF NOT EXISTS clips (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    content     TEXT NOT NULL,
    content_type TEXT NOT NULL DEFAULT 'text',  -- text | url | code | image_desc
    language    TEXT,                            -- for code clips
    source_url  TEXT,                            -- for URL clips, fetched page title
    session_id  INTEGER NOT NULL,
    copied_at   DATETIME NOT NULL DEFAULT (datetime('now', 'localtime')),
    is_redacted INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS sessions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at  DATETIME NOT NULL,
    ended_at    DATETIME,
    label       TEXT                             -- auto-generated or user-set
);

CREATE TABLE IF NOT EXISTS outputs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id  INTEGER NOT NULL,
    mode        TEXT NOT NULL,                    -- story | summary | worklog | digest | email
    content     TEXT NOT NULL,
    created_at  DATETIME NOT NULL DEFAULT (datetime('now', 'localtime')),
    FOREIGN KEY (session_id) REFERENCES sessions(id)
);
```

### 1.2 Clipboard Monitor (`monitor/clipboard.py`)

Uses the Windows **`WM_CLIPBOARDUPDATE`** message — no polling, zero CPU waste. The monitor runs a hidden Win32 message-loop window on a background thread and is instantly notified by the OS every time the clipboard changes.

```python
import win32api, win32con, win32gui

class ClipboardMonitor(threading.Thread):
    def run(self):
        # Create hidden window, register as clipboard listener
        hwnd = win32gui.CreateWindow(...)
        win32gui.AddClipboardFormatListener(hwnd)
        win32gui.PumpMessages()  # blocks, fires wnd_proc on each message

    def wnd_proc(self, hwnd, msg, wparam, lparam):
        if msg == win32con.WM_CLIPBOARDUPDATE:
            self.on_clipboard_changed()
```

- On `WM_CLIPBOARDUPDATE`: read clipboard via `win32clipboard.GetClipboardData()`
- Classify clip type:
  - `url` — matches URL regex (`https?://...`)
  - `code` — heuristic (contains `def `, `class `, `{`, `=>`, `import`, etc.)
  - `text` — default
- For URL clips: fetch the page `<title>` via `requests` in a thread pool (non-blocking)
- For code clips: detect language via `pygments.lexers.guess_lexer()`
- Store to SQLite via `store.py`

### 1.3 Session Detection (`monitor/session.py`)

- A **new session** is created when the gap since the last clip exceeds a configurable idle threshold (default: **30 minutes**, set in `config.json`)
- On startup, check if an open session exists from < threshold ago; if so, resume it
- Sessions are closed automatically when the app shuts down or a new session starts

### 1.4 Deduplication

- Before inserting a clip, check the last N clips (default: 5) in the current session
- If the new clip's content hash matches any of them, discard it
- Consecutive identical copies (e.g., holding Ctrl+C) are always deduplicated

### 1.5 Privacy Filter

- Before storing, scan content for:
  - Passwords fields: regex patterns like `password=`, `pwd=`, `secret=`, `token=`
  - API keys: long alphanumeric strings (32+ chars), common prefixes (`sk-`, `AIza`, etc.)
  - Email addresses (optional, user can toggle)
- Replace matched segments with `[REDACTED]` and set `is_redacted = 1`
- Privacy filter settings configurable in `config.json`

---

## Phase 2 — LLM Integration

### 2.1 Provider Abstraction (`llm/provider.py`)

```python
class LLMProvider(ABC):
    def complete(self, system: str, user: str) -> str: ...

class OpenAIProvider(LLMProvider): ...   # uses openai SDK
class GeminiProvider(LLMProvider): ...   # uses google-generativeai SDK
class OllamaProvider(LLMProvider): ...   # uses ollama SDK (local)
```

Factory function `get_provider()` reads `config.json` to select the active provider and model.

### 2.2 Output Modes & Prompt Templates (`llm/prompts.py`)

| Mode | Key | Description |
|---|---|---|
| Narrative Story | `story` | First-person flowing prose of the session |
| Activity Summary | `summary` | Bullet-point list of what was worked on |
| Work Log | `worklog` | Chronological, timestamped, standup-ready |
| Research Digest | `digest` | Synthesizes research/reading clips into findings |
| Email Draft | `email` | Progress update email to a manager/team |
| PDF Report | `report` | Detailed structured report (feeds into PDF export) |

Each template receives:
- `{session_date}` — date/time of session
- `{clips_text}` — formatted list of all clips with timestamps and types
- `{session_duration}` — human-readable duration

### 2.3 Generator (`llm/generator.py`)

- Accepts `session_id`, `mode`, and optional `clip_ids` list
- If `clip_ids` is provided, fetches only those specific clips (in chronological order)
- Otherwise fetches all clips for the session from DB
- Formats them into the prompt template
- Calls the provider
- Saves output to `outputs` table (stores `clip_ids` used for traceability)
- Returns generated text

---

## Phase 3 — Web UI

### 3.1 Flask API Routes (`web/app.py`)

| Method | Route | Description |
|---|---|---|
| GET | `/api/sessions` | List all sessions |
| GET | `/api/sessions/<id>/clips` | Get clips for a session |
| GET | `/api/sessions/<id>/outputs` | Get all saved outputs for a session |
| POST | `/api/sessions/<id>/generate` | Generate output — body: `{"mode": "summary", "clip_ids": [1,4,7]}` (omit `clip_ids` to use all clips) |
| GET | `/api/sessions/<id>/export/pdf` | Download PDF (respects last `clip_ids` selection) |
| GET | `/api/sessions/<id>/export/md` | Download Markdown |
| GET | `/api/status` | Monitor status (running, clip count today) |
| POST | `/api/settings` | Update config |

### 3.2 Frontend UI (`web/templates/index.html`)

**Layout — three-panel design:**

```
┌──────────────┬─────────────────────────┬──────────────────────┐
│  Sessions    │      Clips Viewer        │   Output Panel       │
│  (sidebar)   │   (timeline view)        │   (generated text)   │
│              │                          │                      │
│  📅 Today    │  [14:01] Copied URL      │  [Narrative Story ▼] │
│  📅 Yesterday│  [14:03] Copied code     │                      │
│              │  [14:15] Copied text     │  Once upon a time... │
│              │                          │                      │
│              │                          │  [Generate] [Export] │
└──────────────┴─────────────────────────┴──────────────────────┘
```

**Features:**
- Session list with date, clip count, duration
- Clips shown in a timeline with type badges (URL, code, text)
- **Clip multi-selection** — each clip has a checkbox; click or shift-click to range-select
  - Toolbar shows: `"12 of 34 clips selected"` with **Select All / Clear** buttons
  - Generate and Export operate on the selected subset only
  - If nothing selected, defaults to all clips in the session
- Output mode selector dropdown
- "Generate" button triggers LLM call (with loading spinner)
- Export buttons: PDF, Markdown, plain text
- Settings page: LLM provider, model, API key, session gap, privacy toggles

### 3.3 Design — Dark Mode, Modern Aesthetic
- Color palette: deep slate background (`#0f172a`), accent `#6366f1` (indigo)
- Google Font: **Inter**
- Glassmorphism cards for clips
- Smooth animations on panel transitions
- Syntax highlighting for code clips (using highlight.js CDN)

---

## Phase 4 — Export

### 4.1 PDF Report (`export/pdf.py`)

Uses `reportlab` to generate a structured PDF:

```
Page 1: Cover — Session Date, Duration, Clip Count, App Logo
Page 2: Executive Summary (LLM-generated)
Page 3+: Detailed Clip Timeline — each clip in a styled block
Last Page: Full Generated Output (story/worklog/etc.)
```

### 4.2 Markdown Export (`export/markdown.py`)

```markdown
# clipstitch — Session Report
**Date:** 2026-03-06  
**Duration:** 2h 15m  
**Clips:** 32

## Summary
...

## Clip Timeline
| Time | Type | Content |
|------|------|---------|
| 14:01 | URL  | https://... |
...

## Full Output
...
```

---

## Phase 5 — Tray & Hotkeys

### 5.1 System Tray (`tray/icon.py`)

- Icon with right-click menu:
  - ✅ **Open Dashboard** — opens `http://localhost:5050` in browser
  - 📋 **Generate Summary** — quick-generate summary of current session
  - ⏸ **Pause Monitoring**
  - ⚙️ **Settings**
  - ❌ **Quit**
- Icon badge shows clip count for current session

### 5.2 Global Hotkey

- Default: `Ctrl+Shift+S` → open dashboard in browser
- Default: `Ctrl+Shift+G` → immediately generate and show summary in a popup
- Configurable in `config.json`

---

## Configuration (`config.json`)

```json
{
  "llm": {
    "provider": "openai",
    "model": "gpt-4o-mini",
    "ollama_host": "http://localhost:11434",
    "ollama_model": "llama3"
  },
  "monitor": {
    "session_gap_minutes": 30,
    "dedup_window": 5
  },
  "privacy": {
    "redact_api_keys": true,
    "redact_passwords": true,
    "redact_emails": false
  },
  "web": {
    "port": 5050,
    "open_on_start": false
  },
  "hotkeys": {
    "open_dashboard": "ctrl+shift+s",
    "quick_generate": "ctrl+shift+g"
  }
}
```

---

## Dependencies (`requirements.txt`)

```
pyperclip
pywin32
flask
openai
google-generativeai
ollama
reportlab
Pillow
pystray
keyboard
python-dotenv
requests
pygments
```

---

## Build Order

```
Phase 1:  db/ → monitor/ → CLI test
Phase 2:  llm/ → generator test
Phase 3:  web/ (Flask API + UI)
Phase 4:  export/ (PDF + Markdown)
Phase 5:  tray/ + hotkeys
Final:    Packaging with PyInstaller
```

---

## Verification Plan

### Automated Tests

Run with:
```bash
cd d:\Programming\clipstitch
python -m pytest tests/ -v
```

| Test File | Covers |
|---|---|
| `test_clipboard.py` | Clip type detection, deduplication, privacy filter |
| `test_session.py` | Session creation, gap detection, session resume |
| `test_store.py` | CRUD operations, schema integrity |
| `test_generator.py` | Prompt formatting, mock LLM responses |
| `test_export.py` | PDF file creation, Markdown formatting |

### Manual Verification

1. **Clipboard monitor**: Copy 5 different things → open dashboard → verify all appear in clip list with correct types and correct timestamps
2. **Event-driven**: Verify clips appear in the UI instantly (no perceptible delay) after copying — no polling lag
3. **Dedup**: Copy the same text twice in a row → verify only one clip stored
4. **Privacy filter**: Copy the string `password=mysecret123` → verify it shows as `[REDACTED]` in UI
5. **Clip range selection**: Select clips 2–5 using shift-click → click Generate → verify LLM output only references those clips' content
6. **LLM generation (all clips)**: Clear selection → click Generate in "Summary" mode → verify output references all clips
7. **PDF export**: Click "Export PDF" → verify downloaded file opens correctly with content
8. **Session gap**: Temporarily lower gap to 1 min in config → wait → copy something → verify a new session is created
9. **Tray icon**: Check icon appears in system tray, menu items work, hotkeys respond

---

## Future Ideas (Post-MVP)

- **Browser extension** to also capture tabs opened (not just clipboard)
- **Voice memo** mode — transcribe audio clips
- **Day planner integration** — export work log to Notion/Obsidian
- **AI tagging** — auto-classify sessions as "coding", "research", "writing"
- **Multi-monitor** support for image clips
- **Encryption at rest** for the SQLite database
