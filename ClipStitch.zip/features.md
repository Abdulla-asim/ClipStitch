# clipstitch — Product Features & User Stories

## Business Idea

> **clipstitch** is a Windows desktop utility that silently watches your clipboard, remembers everything you copy, and uses AI to turn those fragments into coherent narratives — work logs, research digests, penetration test walkthroughs, progress emails, or PDF reports — with zero extra effort from the user.

**Target market:** Knowledge workers, developers, **cybersecurity analysts and penetration testers**, researchers, writers, and students who copy dozens of things a day but lose the context of what they were doing minutes later.

**Value proposition:** You already copy things constantly. clipstitch turns that passive behaviour into structured, exportable intelligence — no note-taking discipline required.

> 🔐 **Cybersecurity use case:** Security analysts copy commands, log snippets, CVE references, IP addresses, tool outputs, and findings throughout an engagement. clipstitch automatically captures and organises this trail, then uses AI to generate professional incident reports, pentest walkthroughs, and findings summaries — turning clipboard fragments into audit-ready documentation.

---

## Implemented Features — User Stories

### 🗂️ Clipboard Monitoring

**US-01**
> *As a developer who constantly copies code snippets and Stack Overflow URLs, I want the app to silently capture everything I copy without interrupting my flow, so I can review my research trail at the end of the day.*

**US-02**
> *As a knowledge worker, I want the app to automatically detect whether I copied a URL, a code snippet, or plain text, so my history is organised by type without any manual tagging.*

**US-03**
> *As a user who sometimes accidentally copies the same thing multiple times, I want duplicate clips to be silently discarded, so my history stays clean and readable.*

**US-04**
> *As a developer working with APIs, I want the app to automatically redact passwords, API keys, and tokens before storing them, so I never accidentally save sensitive credentials to disk.*

---

### 🕐 Sessions

**US-05**
> *As a freelancer who works on multiple projects throughout the day, I want my clipboard activity automatically grouped into sessions based on idle time, so I get a separate, reviewable history for each work block.*

**US-06**
> *As a remote worker who sometimes steps away from the computer mid-task, I want the app to intelligently resume the same session when I return quickly, rather than creating a new session for every short break.*

---

### ✦ AI Generation

**US-07**
> *As a developer doing end-of-day standups, I want to click one button and get a bullet-point summary of what I worked on, generated from my clipboard history, so I never have to reconstruct my day from memory.*

**US-08**
> *As a researcher who reads and copies content from many sources, I want to generate a structured research digest that synthesises my findings, so I can quickly share a summary of what I learned.*

**US-09**
> *As a manager who needs to write progress emails frequently, I want to generate a polished email draft from my clipboard activity, so I can send updates without writing them from scratch.*

**US-10**
> *As a technical writer, I want to generate a detailed, structured PDF report of a session, so I can attach a professional document to tickets or handoffs.*

**US-11**
> *As a user wanting to capture a specific conversation or research thread, I want to select a subset of clips using checkboxes and shift-click range selection, so the AI output only covers what I choose — not the entire session.*

---

### 📄 Export

**US-12**
> *As a consultant who needs to send proof-of-work to clients, I want to export a session as a styled PDF report with cover page, clip timeline, and AI summary, so I have a professional deliverable.*

**US-13**
> *As a developer who uses Obsidian or Notion, I want to export session reports as Markdown files, so I can drop them into my knowledge base without reformatting.*

---

### ⚙️ Settings & Privacy

**US-14**
> *As a user who sometimes works with confidential client data, I want granular privacy controls — toggle email, password, and API key redaction separately — so I can control exactly what gets stored.*

**US-15**
> *As a power user, I want to configure the AI provider (OpenAI, Gemini, or local Ollama), model name, and session gap duration from a settings UI, so I can tune the app to my workflow without editing config files.*

---

### 🖥️ System Tray & Hotkeys

**US-16**
> *As a user who doesn't want a window cluttering my taskbar, I want clipstitch to run as a tray icon in the background and open the dashboard only when I want it, so it stays out of my way.*

**US-17**
> *As a power user, I want a global hotkey (Ctrl+Shift+S) to open the dashboard from anywhere, so I don't have to find the tray icon every time.*

**US-18**
> *As a busy professional, I want a "Pause Monitoring" option in the tray menu, so I can temporarily stop capturing when I'm handling sensitive information.*

---

### 🔐 Cybersecurity Analyst Workflow

**US-19**
> *As a penetration tester, I want the app to silently capture every command I run and every output I copy from a terminal session, so I have a complete, chronological record of my engagement without manually maintaining notes.*

**US-20**
> *As a SOC analyst correlating a security incident, I want to copy log lines, IP addresses, and threat intel from multiple sources and then generate a structured incident report, so I can document my findings without retyping what I already collected.*

**US-21**
> *As a red team operator, I want to select a specific set of clips covering one attack chain — reconnaissance, exploitation, and post-exploitation — and generate a focused walkthrough report, so my report covers only that kill chain and not unrelated activity.*

**US-22**
> *As a vulnerability researcher writing a disclosure report, I want to paste CVE references, proof-of-concept code, and affected version strings, then export a professionally formatted PDF, so I can send a polished report to a vendor without hours of formatting.*

**US-23**
> *As a security analyst handling sensitive client data, I want to pause clipboard monitoring with a single click before copying secrets or credentials I don't want stored, so I stay in full control of what the app sees.*

---

## Future Feature Ideas — User Stories

### 🔐 Future — Cybersecurity Analyst

**US-24**
> *As a penetration tester, I want the app to recognise common security tool output patterns (Nmap results, Metasploit sessions, Burp Suite snippets) and tag them automatically, so my timeline is annotated with what tool each clip came from.*

**US-25**
> *As a threat hunter, I want to export a session as a MITRE ATT&CK-mapped report — where the AI attempts to map my findings to tactics and techniques — so I can include an ATT&CK matrix reference in my deliverables.*

**US-26**
> *As a CTF player, I want a "Challenge Walkthrough" generation mode that turns my clipboard history into a step-by-step writeup, so I can publish solutions quickly after a competition ends.*

**US-27**
> *As an incident responder, I want to tag a session as an "incident" and generate a timeline report ordered by event timestamps found within my copied log lines, so my report reflects the actual attack sequence rather than the order I discovered things.*

---

### 🌐 Browser & Context Awareness

**US-28**
> *As a researcher, I want the app to automatically fetch the title and a one-sentence description of any URL I copy, so my clip history shows what the page was about — not just the raw link.*

**US-29** *(partially implemented — title fetch exists)*
> *As a user, I want to optionally fetch a short excerpt from copied URLs (a preview of the page content), so the AI has richer context when generating summaries.*

---

### 🏷️ AI Tagging & Classification

**US-30**
> *As a user who alternates between coding, research, and writing, I want each session to be automatically labelled (e.g. "Coding — Python", "Research — ML papers"), so I can find past sessions by topic without scrolling through dates.*

**US-31**
> *As a team lead, I want individual clips to be tagged with their likely intent (e.g. "debugging", "reference", "task note"), so I can filter my clip history by what I was trying to do.*

---

### 🔒 Encryption & Security

**US-32**
> *As a security-conscious professional, I want the local SQLite database to be encrypted at rest, so my clipboard history cannot be read if my laptop is lost or stolen.*

**US-33**
> *As a team administrator, I want to set a master password that locks the clipstitch dashboard, so no one else can read my clipboard history.*

---

### 📅 Integrations & Export

**US-34**
> *As a developer using GitHub, I want to export a work log directly as a GitHub Gist, so I can link it to issues or pull requests.*

**US-35**
> *As a Notion user, I want to push generated summaries and work logs directly to a Notion page via API, so my knowledge base is updated automatically.*

**US-36**
> *As an Obsidian user, I want a one-click "Save to Vault" export that writes the Markdown report into my Obsidian vault folder, so my notes are always up to date.*

---

### 📊 Analytics & Dashboard

**US-37**
> *As a freelancer who tracks billable hours, I want a weekly view that shows total clipboard activity per day and session durations, so I can estimate how long different projects took.*

**US-38**
> *As a productivity enthusiast, I want a heatmap of my clipboard activity by hour and day of week, so I can understand when I'm most productive.*

**US-39**
> *As a manager, I want to search my clip history by keyword across all sessions, so I can find a specific piece of information I copied weeks ago.*

---

### 🖼️ Image & Multimedia Clips

**US-40**
> *As a designer, I want the app to capture screenshots I copy to clipboard and store a thumbnail, so my session history includes visual references — not just text.*

**US-41**
> *As a user who copies charts or diagrams, I want the AI to describe image clips using vision capabilities (GPT-4o / Gemini), so image context is included in generated summaries.*

---

### 🤝 Team & Collaboration

**US-42**
> *As an engineering manager, I want team members to optionally share their daily work logs (with privacy controls), so I get an aggregated view of what the team worked on without requiring standups.*

**US-43**
> *As a pair-programming partner, I want to export a shared session report when two people collaborate on the same feature, so both contributors have a record of the session.*

---

### 🗣️ Voice & Input Modes

**US-44**
> *As a user who prefers dictation, I want to add voice memos to a session — transcribed automatically — so my session history includes spoken notes alongside clipboard content.*

---

## Prioritisation Note

| Priority | User Stories |
|----------|-------------|
| ✅ Shipped | US-01 – US-18 (core app), US-19 – US-23 (security analyst workflow), US-40 (image capture), US-41 (vision AI description) |
| 🔜 High value, low effort | US-26 (CTF walkthrough mode), US-29 (URL excerpts), US-30 (AI session labels), US-39 (keyword search) |
| 🧩 Medium effort | US-24 (tool output tagging), US-25 (ATT&CK report), US-27 (incident timeline), US-32 (encryption), US-34 (Gist), US-35 (Notion), US-37 (analytics) |
| 🚀 Big bets | US-42, US-43 (team features), US-44 (voice) |

